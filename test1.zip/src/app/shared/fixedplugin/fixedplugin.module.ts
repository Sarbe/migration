import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FixedpluginComponent } from './fixedplugin.component';

@NgModule({
  imports: [ RouterModule, CommonModule ],
  declarations: [ FixedpluginComponent ],
  exports: [ FixedpluginComponent ]
})
export class FixedpluginModule { }
