import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-manual',
  templateUrl: './dropdown-manual.component.html',
  styleUrls: ['./dropdown-manual.component.css']
})
export class DropdownManualComponent implements OnInit {

  constructor() { }

  time = {hour: 13, minute: 30};
  meridian = true;

  toggleMeridian() {
      this.meridian = !this.meridian;
  }
  ngOnInit() {
  }

}
