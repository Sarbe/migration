import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule, NgbDropdownModule} from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { AppRoutingModule } from './app-routing.module';
import { SidebarModule } from './sidebar/sidebar.module';
import { FooterComponent } from './shared/footer/footer.component';
import { FooterModule } from './shared/footer/footer.module';
import { FixedpluginComponent } from './shared/fixedplugin/fixedplugin.component';
import { FixedpluginModule } from './shared/fixedplugin/fixedplugin.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DropdownManualComponent } from './dropdown-manual/dropdown-manual.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DashboardComponent,
    DropdownManualComponent
  ],
  imports: [
    NgbModule,
    BrowserModule,
    AppRoutingModule,
    SidebarModule,
    FooterModule,
    FixedpluginModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
